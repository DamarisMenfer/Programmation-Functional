import matplotlib.pyplot as plt
import matplotlib.lines as lines
from matplotlib.patches import Rectangle

#[(13,3,8),(5,3,9),(19,4,12),(3,4,5),(10,7,5),(7,2,4),(1,2,5),(21,7,12)]

immeubles_tests = [(13,3,8),(5,3,9),(19,4,12),(3,4,5),(10,7,5),(7,2,4),(1,2,5),(21,7,12)]

ligne_de_toits = []

# Dimensionnement de la fenetre
def initialisation(n):
	plt.figure(n)
	plt.xlim([0,30])
	plt.ylim([0,20])

def dessiner_immeubles(immeubles):
	ax = plt.gca()
	for (x,w,h) in immeubles:
		ax.add_patch(Rectangle((x,0), w, h,fill=None,linewidth=5))

def dessiner_ligne(ligne):
	ax = plt.gca()
	X,Y=0,0
	for (x,y) in ligne:
		# X Y -> x Y -> x y
		ax.add_line(lines.Line2D([X,x,x], [Y,Y,y], linewidth=1, color='red'))
		X=x
		Y=y
		
		




# ---------------
# PREMIERE PARTIE
# ---------------

def ajouter_immeuble(ligne,immeuble):
	(x,w,h) = immeuble

	j = 0
	while j < len(ligne):
		print(ligne[j])
		j = j+1	

	resultat = []
	i=0

	# Tant qu'on est a gauche de l'immeuble
	while i < len(ligne) and ligne[i][0] < x:
		resultat.append(ligne[i])		
		i = i+1
		
	# Ajout du mur de gauche si besoin
	if i < len(ligne):
		# Si le mur est a la meme abscisse qu'un autre
		if x == ligne[i][0]:
			if h > ligne[i][1]:
				resultat.append((x,h))
			elif h < ligne[i][1]:
				resultat.append(ligne[i])
		else:
			if h >= ligne[i-1][1]:
				resultat.append((x,h))
			else:
				resultat.append(ligne[i])
	else:
		resultat.append((x,h))

		
	# Tant qu'on est a l'interieur de l'immeuble
	while i < len(ligne) and ligne[i][0] < x+w:
		print (h)
		print (ligne[i])
		print (ligne[i-1])
		if h >= ligne[i][1]:
			resultat.append((x+w,h))
		else:
			resultat.append((ligne[i][0],h))
			resultat.append((ligne[i]))
		i = i+1

	# Ajout du mur droit
	if i < len(ligne):
		# Meme abscisse qu'un autre mur
		if x+w == ligne[i][0]:
			resultat.append((x+w,h))
			resultat.append((x+w,ligne[i][1]))
		else:
			if h >= ligne[i-1][1]:
				resultat.append((x+w,0))
			else:
				resultat.append(ligne[i])
				i = i+1
	else:
		resultat.append((x+w,0))

	# Tant qu'on est a droite de l'immeuble
	while i < len(ligne):
		resultat.append(ligne[i])
		i = i+1
		pass

	return resultat


# Pour visualiser un resultat :
initialisation(1)
dessiner_immeubles(immeubles_tests)
for immeubles in immeubles_tests:
	ligne_de_toits = ajouter_immeuble(ligne_de_toits, immeubles)
dessiner_ligne(ligne_de_toits)
plt.show()
# L'appel a "plt.show()" bloque le code. L'execution continue lorsqu'on ferme la fenetre graphique.
	
exit()	
	
# ---------------
# DEUXIEME PARTIE
# ---------------

def fusion_lignes(l1,l2):
	resultat=[(0,0)]

	#--------------
	# Quelque chose
	#--------------
	
	return resultat


def creer_ligne(immeubles):
	# Cas de base
	if True: # A changer...
		ligne = []
		#--------------
		# Quelque chose
		#--------------
		return ligne
	# Cas general
	else:
		# Separation en deux sous-problemes
		#--------------
		# Quelque chose
		#--------------
		
		# Resolution des sous-problemes
		#--------------
		# Quelque chose
		#--------------

		# Fusion
		#--------------
		# Quelque chose
		#--------------

		ligne = []
		return ligne

#-------------------------
# TEST DIVISER POUR REGNER
#-------------------------

#initialisation(1)
#dessiner_immeubles(immeubles)
#L=creer_ligne(immeubles)
#dessiner_ligne(L)
#plt.show()
