open Graph

let fordFulkerson graph source sink =
	let flowGraph = { vertices = map_hashtbl graph.vertices
		           (fun inf -> 
		              { label = vmap inf.label;
		                id = inf.id;
		                outedges = List.map (fun (a,b)-> (a, 0)) inf.outedges;
		                inedges = List.map  (fun (a,b)-> (a, 0)) inf.inedges}
		           )
		     }
		     in flowGraph;;
