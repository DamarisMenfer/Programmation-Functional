type id = string

type ('v, 'e) vertex_info =
  { label: 'v ;
    id: id ;
    outedges: ('e * id) list ;
    inedges: ('e * id) list }

type ('v, 'e) graph =
  { (* Hashtable mapping identifiers to vertex_info. *)
    vertices: (id, ('v, 'e) vertex_info) Hashtbl.t ;
  }
  (*a graph is a hashtbl vertices with tuples made up of
    an id and a vertexinfo
    each vertexinfo defines an vertice with its outgoing and ingoing edges
    where each edge is defined by the id of that vertex and its weight?
  *)

let find_vertex graph id =
  try Hashtbl.find graph.vertices id
  with Not_found -> failwith ("Vertex " ^ id ^ " cannot be found in this graph.")

let find_edge graph id1 id2 =
  try
    let info = find_vertex graph id1 in
    let (e, _) = List.find (fun (_, id) -> id = id2) info.outedges in
    Some e
   with Not_found -> None

(**************  CONSTRUCTORS  **************)

let new_graph () = { vertices = Hashtbl.create 60 }

let add_vertex graph label id =
  if Hashtbl.mem graph.vertices id then
    let info = Hashtbl.find graph.vertices id in
    Hashtbl.replace graph.vertices id { info with label }
  else
    Hashtbl.add graph.vertices id { label ; id ; outedges = [] ; inedges = [] }

(* Insert or replace a pair (label * id) in a list. *)
let rec insert acu id label = function
  | [] -> (label, id) :: acu
  | (_, id2) as pair :: rest ->
    if id = id2 then List.rev_append rest ((label, id) :: acu)
    else insert (pair :: acu) id label rest

let add_edge graph id1 id2 elabel =

  (* Get vertex_info of origin and destination. *)
  let origin_info = find_vertex graph id1
  and dest_info   = find_vertex graph id2 in

  (* Add (or replace) the given edge. *)
  let new_outedges = insert [] id2 elabel origin_info.outedges
  and new_inedges  = insert [] id1 elabel dest_info.inedges in
  
  (* Put it back in the hashtable. *)
  Hashtbl.replace graph.vertices id1 { origin_info with outedges = new_outedges } ;
  Hashtbl.replace graph.vertices id2 { dest_info with inedges = new_inedges } ;

  (* Done. *)
  ()


(**************  COMBINATORS, ITERATORS  **************)

let v_iter graph f = Hashtbl.iter (fun _ info -> f info) graph.vertices

(* Creates a new hashtable by mapping f to every value. *)
let map_hashtbl h f =
  let result = Hashtbl.create (Hashtbl.length h) in
  Hashtbl.iter (fun key v -> Hashtbl.add result key (f v)) h ;
  result;;

(* let map graph vmap emap = assert false  *)
(* uses function vmap to map vertex and emap function for edges*)
(* 
 * Beware that emap is called twice on each edge (ingoing and outgoing). 
 *
 * map: ('v1, 'e1) graph -> ('v1 -> 'v2) -> ('e1 -> 'e2) -> ('v2, 'e2) graph  *)

let map graph vmap emap = 
  let newg = { vertices = 
                 map_hashtbl graph.vertices
                   (fun inf -> 
                      { label = vmap inf.label;
                        id = inf.id;
                        outedges = List.map (fun (a,b)-> (emap a, b)) inf.outedges;
                        inedges = List.map  (fun (a,b)-> (emap a, b)) inf.inedges}
                   )
             }
             in newg;;



(**************  FORD-FULKERSON  **************)

(*Find a augmenting path in the graph and return a list with the vertices of the augmenting path.*)
let rec findAugmentingPath graph source sink =
	match find_edge graph source sink with
	| Some e ->
		if e > 0 then [source; sink] else []
	| None -> [];;
		(*Here I tried to make an iterator in the list of outedges of source, but I failed.*)
		(*let new_source = find_vertex graph source in
		List.iter (fun (label,id_new_s) -> source::(findAugmentingPath graph id_new_s sink)) new_source.outedges*)

(*Find the value of maximum flow of the augmenting path.*)
(*Here is the problem with the polymorphism, because of the 10000 in the line "loop graph path 10000"*)
let maxGraphFlow graph path =
	let rec loop graph path maxFlow = 
		match path with
		|[] -> maxFlow
		|[x] -> maxFlow
		|id1::id2::rest ->
			(*If the edge flow is smaller then max flow, make max flow equal to edge flow.*)
			(*Else, keep with the max flow.*)
			begin match find_edge graph id1 id2 with
			|Some edgeFlow ->
				if edgeFlow < maxFlow then loop graph (id2::rest) edgeFlow else loop graph (id2::rest) maxFlow
			(*If we dont find an edge between the two vertices, there is a problem with the augmenting path.*)
			|None ->
				failwith ("Error in augmenting path.")
			end
	in
	loop graph path 10000;;

let add_edges_residual_graph graph id1 id2 maxFlow =
	match find_edge graph id1 id2 with
	|Some edge_source_to_sink ->
		add_edge graph id2 id1 maxFlow;
		add_edge graph id1 id2 (edge_source_to_sink-maxFlow);
		graph
	|None ->
		failwith ("Error in augmenting path.");;

(*Take the actual residual graph and actualise it.*)
(*To understand more, take a look at the video that I sent to you.*)
let actualiseResidualGraph graph path maxFlow =
	let rec loop graph path maxFlow = 
		match path with
		|[] -> graph
		|[x] -> graph
		|id1::id2::rest ->
			(*We have to add two edges in the residual graph -> the video explain it.*)
			let graph1 = add_edges_residual_graph graph id1 id2 maxFlow in
			loop graph1 (id2::rest) maxFlow
	in
	loop graph path maxFlow;;


let actualiseFlowGraph flowGraph path maxFlow =
	let rec loop flowGraph path maxFlow = 
		match path with
		|[] -> flowGraph
		|[x] -> flowGraph
		|id1::id2::rest ->
			add_edge flowGraph id1 id2 maxFlow;
			loop flowGraph (id2::rest) maxFlow
	in
	loop flowGraph path maxFlow;;

	
	
(*Take a graph a source and a sink and return the maximum flow graph.*)
(*To improve -> I had to change the type of the graph to ('v1, int) graph (take a look at maxGraphFlow), but the more polymorphic would be ('v1, 'e1) graph*)
let fordFulkerson graph source sink =
	(*Creates the flowGraph with 0 flow in the begining.*)
	let flowGraph = map graph (fun x -> x) (fun x -> 0) in
	(*While there is a augmenting path in the residual graph, augment flow.*)
	(*Else, return flow graph.*)
	let rec loop graph source sink flowGraph =
		match findAugmentingPath graph source sink with
		|[] -> flowGraph
		|path -> 
			let maxFlow = maxGraphFlow graph path in
			loop (actualiseResidualGraph graph path maxFlow) source sink (actualiseFlowGraph flowGraph path maxFlow)
	in
	loop graph source sink flowGraph;;

	








